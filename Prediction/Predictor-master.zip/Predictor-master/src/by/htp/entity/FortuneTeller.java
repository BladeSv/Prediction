package by.htp.entity;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.TreeSet;

public class FortuneTeller {
	HashMap<Integer, Client> BaseProcessedClients;
LinkedHashMap<Predection, Queue<Answer>> Predections;	
//private TreeSet <Predections> variantsPrediction;

public LinkedHashMap<Predection, Queue<Answer>> getPredections() {
	return Predections;
}

public void setPredections(LinkedHashMap<Predection, Queue<Answer>> predections) {
	Predections = predections;
}

//private Map variansPrediction;



}
