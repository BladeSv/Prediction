package by.htp.entity;

public class MainMenu {

	public void mainMenu() {
		FortuneTeller fortuneTeller=new FortuneTeller();
		MainQuety mainQuety =new MainQuety();
		Run run=new Run();
		WaitQuety waitQuety=new  WaitQuety();
		
		
		System.out.println("Add Clint to MainQuety");
		mainQuety.getMainQueue().add(Client.creatClient());
		System.out.println("Admission");
		run.admission(mainQuety, fortuneTeller);
		
		
	}
	
	
	
}
