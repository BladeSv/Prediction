package by.htp.entity;

import java.util.ArrayList;
import java.util.List;

public class BaseClient {
List<Client> baseClint=new ArrayList<>();

}
