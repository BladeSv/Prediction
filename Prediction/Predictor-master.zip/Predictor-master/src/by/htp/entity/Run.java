package by.htp.entity;

import java.util.Map;

public class Run {
private int orderday=0;
private int dayAdmission=0;


public void admission(MainQuety mainQuety, FortuneTeller fortuneTeller) {
	Client tempClient=mainQuety.getMainQueue().poll();
	if((orderday<10)&&((tempClient.getDate()-dayAdmission)<7)){
		if(fortuneTeller.getPredections().containsValue(tempClient.getTargetClient())) {
			fortuneTeller.getPredections().
		Answer answerTemp=fortuneTeller.getPredections().get(tempClient.getTargetClient()).peek();
		
		PredictionResult pRTemp=new PredictionResult();
		
		pRTemp.getPredictionResult().put(key, value)
		
		tempClient.getHistoryPredictions().put(dayAdmission, new );
		
		
		
	
		
		}
		
	}
}
}
