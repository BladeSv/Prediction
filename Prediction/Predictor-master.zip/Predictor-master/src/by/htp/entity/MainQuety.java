package by.htp.entity;

import java.util.PriorityQueue;

public class MainQuety {
	PriorityQueue <Client> mainQueue =new PriorityQueue<Client>();

	public PriorityQueue<Client> getMainQueue() {
		return mainQueue;
	}

	public void setMainQueue(PriorityQueue<Client> mainQueue) {
		this.mainQueue = mainQueue;
	}
	
}
