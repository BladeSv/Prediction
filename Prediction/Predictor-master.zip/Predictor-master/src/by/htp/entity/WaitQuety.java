package by.htp.entity;

import java.util.PriorityQueue;

public class WaitQuety {
	PriorityQueue <Client> waitQuety =new PriorityQueue<Client>();

	public PriorityQueue<Client> getWaitQuety() {
		return waitQuety;
	}

	public void setWaitQuety(PriorityQueue<Client> waitQuety) {
		this.waitQuety = waitQuety;
	}
	
}
