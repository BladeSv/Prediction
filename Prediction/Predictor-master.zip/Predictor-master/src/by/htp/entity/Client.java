package by.htp.entity;


import java.util.Map;
import java.util.Queue;
import java.util.TreeMap;

public class Client {
	private static int id;
	private String name;
	private int date;
		
	TreeMap <Integer, PredictionResult> HistoryPredictions; 
	
	
	

	
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public TreeMap<Integer, PredictionResult> getHistoryPredictions() {
		return HistoryPredictions;
	}

	public void setHistoryPredictions(TreeMap<Integer, PredictionResult> historyPredictions) {
		HistoryPredictions = historyPredictions;
	}

	

	private String targetClient;
public String getTargetClient() {
		return targetClient;
	}

	public void setTargetClient(String targetClient) {
		this.targetClient = targetClient;
	}



public int getDate() {
	return date;
}

public void setDate(int date) {
	this.date = date;
} 

public void seeAnswers(FortuneTeller fort) {
	for( Answer s: fort.getPredections().get(targetClient) ) {
		System.out.println(s.getAnswer());
	}
	
	
	
}
public static Client creatClient() {
	Client client =new Client();
	client.setName("Name"+id);
	client.setTargetClient("targetClient"+id);
	
	id++;
	return client;
}


}
