package by.htp.entity;

public class Predection {
private String target;

public String getTarget() {
	return target;
}

public void setTarget(String target) {
	this.target = target;
}

public Predection(String target) {
	super();
	this.target = target;
}

	
}
